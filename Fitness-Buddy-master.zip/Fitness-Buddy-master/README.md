extract and open 
then go to cmd and type "code ."
it will redirect to vs code
in that open terminal and type "pip install -r requirements.txt"
then run "python app.py"
