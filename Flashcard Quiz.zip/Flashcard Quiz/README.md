

1. install nodejs [here](https://nodejs.org/en)
2. Navigate to the project directory.
3. Run `npm install` to install dependencies.
4. Run `npm run dev` to start the development server.
5. Open the provided URL in a web browser to access the application.

